
"""
Adapters to wire the regression tests into your actual code.
Replace the stubs with imports/calls from your project.
"""
from typing import Dict, Any, Set

class _NotWired(Exception):
    pass

def classify_urgency(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Expected return, e.g.:
    {
      "urgency": "CRITICAL" | "HIGH" | "MODERATE" | "LOW",
      "matched_keywords": ["sudden","paralyzed",...],
      "safety_gate_blocked": False,
      "score": 78.6
    }
    """
    raise _NotWired("Wire this to your real classify/runner function")

def get_matched_keywords(result: Dict[str, Any]) -> Set[str]:
    return set(result.get("matched_keywords", []) or [])

def was_safety_gate_blocked(result: Dict[str, Any]) -> bool:
    return bool(result.get("safety_gate_blocked", False))

def write_audit_log(case_id: int, result: Dict[str, Any]) -> str:
    # Template no-op: simulate a path without writing anything.
    return f"logs/case_{case_id}.jsonl"
